﻿namespace CalculatorApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.N1 = new System.Windows.Forms.Button();
            this.N2 = new System.Windows.Forms.Button();
            this.N0 = new System.Windows.Forms.Button();
            this.N8 = new System.Windows.Forms.Button();
            this.N9 = new System.Windows.Forms.Button();
            this.N7 = new System.Windows.Forms.Button();
            this.N6 = new System.Windows.Forms.Button();
            this.N5 = new System.Windows.Forms.Button();
            this.N4 = new System.Windows.Forms.Button();
            this.N3 = new System.Windows.Forms.Button();
            this.bad = new System.Windows.Forms.Button();
            this.bsub = new System.Windows.Forms.Button();
            this.bmult = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.bdiv = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.bequal = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // N1
            // 
            this.N1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N1.Location = new System.Drawing.Point(62, 101);
            this.N1.Name = "N1";
            this.N1.Size = new System.Drawing.Size(64, 61);
            this.N1.TabIndex = 1;
            this.N1.Text = "1";
            this.N1.UseVisualStyleBackColor = true;
            this.N1.Click += new System.EventHandler(this.N1_Click);
            // 
            // N2
            // 
            this.N2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N2.Location = new System.Drawing.Point(126, 101);
            this.N2.Name = "N2";
            this.N2.Size = new System.Drawing.Size(64, 61);
            this.N2.TabIndex = 2;
            this.N2.Text = "2";
            this.N2.UseVisualStyleBackColor = true;
            this.N2.Click += new System.EventHandler(this.N2_Click);
            // 
            // N0
            // 
            this.N0.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N0.Location = new System.Drawing.Point(126, 281);
            this.N0.Name = "N0";
            this.N0.Size = new System.Drawing.Size(64, 61);
            this.N0.TabIndex = 3;
            this.N0.Text = "0";
            this.N0.UseVisualStyleBackColor = true;
            this.N0.Click += new System.EventHandler(this.N0_Click);
            // 
            // N8
            // 
            this.N8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N8.Location = new System.Drawing.Point(126, 221);
            this.N8.Name = "N8";
            this.N8.Size = new System.Drawing.Size(64, 61);
            this.N8.TabIndex = 4;
            this.N8.Text = "8";
            this.N8.UseVisualStyleBackColor = true;
            this.N8.Click += new System.EventHandler(this.N8_Click);
            // 
            // N9
            // 
            this.N9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N9.Location = new System.Drawing.Point(190, 221);
            this.N9.Name = "N9";
            this.N9.Size = new System.Drawing.Size(64, 61);
            this.N9.TabIndex = 5;
            this.N9.Text = "9";
            this.N9.UseVisualStyleBackColor = true;
            this.N9.Click += new System.EventHandler(this.N9_Click);
            // 
            // N7
            // 
            this.N7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N7.Location = new System.Drawing.Point(62, 221);
            this.N7.Name = "N7";
            this.N7.Size = new System.Drawing.Size(64, 61);
            this.N7.TabIndex = 6;
            this.N7.Text = "7";
            this.N7.UseVisualStyleBackColor = true;
            this.N7.Click += new System.EventHandler(this.N7_Click);
            // 
            // N6
            // 
            this.N6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N6.Location = new System.Drawing.Point(190, 161);
            this.N6.Name = "N6";
            this.N6.Size = new System.Drawing.Size(64, 61);
            this.N6.TabIndex = 7;
            this.N6.Text = "6";
            this.N6.UseVisualStyleBackColor = true;
            this.N6.Click += new System.EventHandler(this.N6_Click);
            // 
            // N5
            // 
            this.N5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N5.Location = new System.Drawing.Point(126, 161);
            this.N5.Name = "N5";
            this.N5.Size = new System.Drawing.Size(64, 61);
            this.N5.TabIndex = 8;
            this.N5.Text = "5";
            this.N5.UseVisualStyleBackColor = true;
            this.N5.Click += new System.EventHandler(this.button7_Click);
            // 
            // N4
            // 
            this.N4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N4.Location = new System.Drawing.Point(62, 161);
            this.N4.Name = "N4";
            this.N4.Size = new System.Drawing.Size(64, 61);
            this.N4.TabIndex = 9;
            this.N4.Text = "4";
            this.N4.UseVisualStyleBackColor = true;
            this.N4.Click += new System.EventHandler(this.N4_Click);
            // 
            // N3
            // 
            this.N3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N3.Location = new System.Drawing.Point(190, 101);
            this.N3.Name = "N3";
            this.N3.Size = new System.Drawing.Size(64, 61);
            this.N3.TabIndex = 10;
            this.N3.Text = "3";
            this.N3.UseVisualStyleBackColor = true;
            this.N3.Click += new System.EventHandler(this.N3_Click);
            // 
            // bad
            // 
            this.bad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(43)))), ((int)(((byte)(24)))));
            this.bad.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bad.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bad.Location = new System.Drawing.Point(254, 101);
            this.bad.Name = "bad";
            this.bad.Size = new System.Drawing.Size(64, 61);
            this.bad.TabIndex = 11;
            this.bad.Text = "+";
            this.bad.UseVisualStyleBackColor = false;
            this.bad.Click += new System.EventHandler(this.button1_Click);
            // 
            // bsub
            // 
            this.bsub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(43)))), ((int)(((byte)(24)))));
            this.bsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bsub.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bsub.Location = new System.Drawing.Point(254, 161);
            this.bsub.Name = "bsub";
            this.bsub.Size = new System.Drawing.Size(64, 61);
            this.bsub.TabIndex = 12;
            this.bsub.Text = "-";
            this.bsub.UseVisualStyleBackColor = false;
            this.bsub.Click += new System.EventHandler(this.bsub_Click);
            // 
            // bmult
            // 
            this.bmult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(43)))), ((int)(((byte)(24)))));
            this.bmult.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmult.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bmult.Location = new System.Drawing.Point(254, 221);
            this.bmult.Name = "bmult";
            this.bmult.Size = new System.Drawing.Size(64, 61);
            this.bmult.TabIndex = 13;
            this.bmult.Text = "*";
            this.bmult.UseVisualStyleBackColor = false;
            this.bmult.Click += new System.EventHandler(this.bmult_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(190, 281);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(64, 61);
            this.button4.TabIndex = 14;
            this.button4.Text = "C";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // bdiv
            // 
            this.bdiv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(43)))), ((int)(((byte)(24)))));
            this.bdiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdiv.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bdiv.Location = new System.Drawing.Point(254, 281);
            this.bdiv.Name = "bdiv";
            this.bdiv.Size = new System.Drawing.Size(64, 61);
            this.bdiv.TabIndex = 15;
            this.bdiv.Text = "/";
            this.bdiv.UseVisualStyleBackColor = false;
            this.bdiv.Click += new System.EventHandler(this.bdiv_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(62, 281);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(64, 61);
            this.button6.TabIndex = 16;
            this.button6.Text = ".";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // bequal
            // 
            this.bequal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(43)))), ((int)(((byte)(24)))));
            this.bequal.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bequal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bequal.Location = new System.Drawing.Point(62, 341);
            this.bequal.Name = "bequal";
            this.bequal.Size = new System.Drawing.Size(256, 61);
            this.bequal.TabIndex = 17;
            this.bequal.Text = "=";
            this.bequal.UseVisualStyleBackColor = false;
            this.bequal.Click += new System.EventHandler(this.bequal_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(69)))), ((int)(((byte)(71)))));
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(62, 42);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(256, 53);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Symbol", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(67, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Calculator";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(62, 408);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(256, 20);
            this.dateTimePicker1.TabIndex = 19;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(197, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 22);
            this.label2.TabIndex = 20;
            this.label2.Text = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(17)))), ((int)(((byte)(22)))));
            this.ClientSize = new System.Drawing.Size(382, 457);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.bequal);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.bdiv);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.bmult);
            this.Controls.Add(this.bsub);
            this.Controls.Add(this.bad);
            this.Controls.Add(this.N3);
            this.Controls.Add(this.N4);
            this.Controls.Add(this.N5);
            this.Controls.Add(this.N6);
            this.Controls.Add(this.N7);
            this.Controls.Add(this.N9);
            this.Controls.Add(this.N8);
            this.Controls.Add(this.N0);
            this.Controls.Add(this.N2);
            this.Controls.Add(this.N1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button N1;
        private System.Windows.Forms.Button N2;
        private System.Windows.Forms.Button N0;
        private System.Windows.Forms.Button N8;
        private System.Windows.Forms.Button N9;
        private System.Windows.Forms.Button N7;
        private System.Windows.Forms.Button N6;
        private System.Windows.Forms.Button N5;
        private System.Windows.Forms.Button N4;
        private System.Windows.Forms.Button N3;
        private System.Windows.Forms.Button bad;
        private System.Windows.Forms.Button bsub;
        private System.Windows.Forms.Button bmult;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button bdiv;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button bequal;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
    }
}

